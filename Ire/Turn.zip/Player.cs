﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ire
{
    class Player
    {
        protected string name = "";
        protected string country = "";
        protected string grade = "";
        protected float rating;
        protected float MMS;
        protected float[] score;
        protected bool[] participation;
        protected int[] opponent;
        protected int pin; //internal id

        public void setPlayer(string n, string c, string g, float r, float m, int tr, int p)
        {
            name = n;
            country = c;
            grade = g;
            rating = r;
            MMS = m;
            score = new float[tr];
            participation = new bool[tr];
            opponent = new int[tr];
            pin = p;

            for (int ii = 0; ii < tr; ii++)
            {
                participation[ii]=true;
                opponent[ii] = -1;
                score[ii] = -1;
            }
        }

        
    }


}
